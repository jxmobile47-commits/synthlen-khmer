// Synthlen Khmer - Self-Extracting Launcher (streaming version)
// Reads ZIP payload appended after marker "SKZIP1\0\0" using streaming
// to support files larger than 2GB.
//
// Build: csc Launcher.cs /out:Launcher.exe /target:exe /platform:anycpu /r:System.IO.Compression.dll /r:System.IO.Compression.FileSystem.dll

using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Text;

class Launcher
{
    static readonly byte[] Marker = Encoding.ASCII.GetBytes("SKZIP1\0\0");

    static int Main(string[] args)
    {
        Console.WriteLine();
        Console.WriteLine("  ========================================");
        Console.WriteLine("    Synthlen Khmer Installer v1.0.0");
        Console.WriteLine("  ========================================");
        Console.WriteLine();

        string exePath = Assembly.GetExecutingAssembly().Location;
        if (string.IsNullOrEmpty(exePath))
            exePath = Process.GetCurrentProcess().MainModule.FileName;

        // Find marker by streaming from the beginning (launcher is small, marker is near start)
        long markerPos = -1;
        try
        {
            markerPos = FindMarker(exePath);
        }
        catch (Exception ex)
        {
            Console.WriteLine("  ERROR reading file: " + ex.Message);
            Console.ReadLine();
            return 1;
        }

        if (markerPos < 0)
        {
            Console.WriteLine("  ERROR: No payload found in this executable.");
            Console.ReadLine();
            return 1;
        }

        long zipStart = markerPos + Marker.Length;

        string tempDir = Path.Combine(Path.GetTempPath(), "SynthlenKhmer_Install");
        string zipFile = Path.Combine(Path.GetTempPath(), "sk_payload.zip");

        // Clean previous
        try { if (Directory.Exists(tempDir)) Directory.Delete(tempDir, true); } catch { }
        try { if (File.Exists(zipFile)) File.Delete(zipFile); } catch { }

        // Stream ZIP portion to temp file (no memory issue - 1MB chunks)
        Console.WriteLine("  Extracting files...");
        try
        {
            using (var src = new FileStream(exePath, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 20))
            {
                src.Position = zipStart;
                using (var dst = new FileStream(zipFile, FileMode.Create, FileAccess.Write, FileShare.None, 1 << 20))
                {
                    src.CopyTo(dst, 1 << 20);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("  ERROR writing ZIP: " + ex.Message);
            Console.ReadLine();
            return 1;
        }

        // Extract ZIP
        try
        {
            Directory.CreateDirectory(tempDir);
            ZipFile.ExtractToDirectory(zipFile, tempDir);
        }
        catch (Exception ex)
        {
            Console.WriteLine("  ERROR extracting: " + ex.Message);
            Console.ReadLine();
            return 1;
        }
        finally
        {
            try { File.Delete(zipFile); } catch { }
        }

        // Run installer.bat
        string batPath = Path.Combine(tempDir, "Install-SynthlenKhmer.bat");
        if (!File.Exists(batPath))
        {
            var bats = Directory.GetFiles(tempDir, "*.bat", SearchOption.AllDirectories);
            if (bats.Length > 0) batPath = bats[0];
        }

        if (File.Exists(batPath))
        {
            var psi = new ProcessStartInfo
            {
                FileName = batPath,
                WorkingDirectory = Path.GetDirectoryName(batPath),
                UseShellExecute = true,
                Verb = "runas"
            };
            try
            {
                var p = Process.Start(psi);
                p.WaitForExit();
                int code = p.ExitCode;
                try { Directory.Delete(tempDir, true); } catch { }
                return code;
            }
            catch (System.ComponentModel.Win32Exception)
            {
                Console.WriteLine("  Administrator permission required. Exiting.");
                Console.ReadLine();
                return 1;
            }
        }
        else
        {
            Console.WriteLine("  ERROR: Install-SynthlenKhmer.bat not found in payload.");
            Console.ReadLine();
            return 1;
        }
    }

    // Search for marker in first 1MB (launcher exe is small, marker is right after it)
    static long FindMarker(string filePath)
    {
        int searchSize = 1 << 20; // 1MB
        byte[] buf = new byte[searchSize];

        using (var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read, searchSize))
        {
            int read = fs.Read(buf, 0, searchSize);
            for (int i = 0; i <= read - Marker.Length; i++)
            {
                bool match = true;
                for (int j = 0; j < Marker.Length; j++)
                {
                    if (buf[i + j] != Marker[j]) { match = false; break; }
                }
                if (match) return (long) i;
            }
        }
        return -1;
    }
}
